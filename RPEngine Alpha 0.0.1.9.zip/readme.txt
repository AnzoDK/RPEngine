Welcome to the first release of the RPEngine.

To get started it is recommeded to run 

./dependency-builder.sh --use-dev

This will update RPAudio to the newest version.

Now you can make an .so file by

make lib

or a windows dll with

make lib OS=Windows

Here after you can copy the contents of the includes folder to your project.
You can link RPEngine with -lrpengine and RPAudio with -rpaudio

Thank you again for using the RPEngine
